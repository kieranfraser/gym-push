from gym_push.envs.basic_env import Basic
from gym_push.envs.evalumap1_env import EvalUMAP1 